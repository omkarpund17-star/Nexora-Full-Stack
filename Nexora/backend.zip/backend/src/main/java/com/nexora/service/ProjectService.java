package com.nexora.service;

import com.nexora.model.*;
import com.nexora.repo.ProjectRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProjectService {
 private final ProjectRepository projects; private final CurrentUserService current;
 public ProjectService(ProjectRepository projects,CurrentUserService current){this.projects=projects;this.current=current;}
 public record ProjectRequest(String name,String description,String client,java.time.LocalDate dueDate){}
 public record ProjectView(Long id,String name,String description,String client,String status,java.time.LocalDate dueDate,String owner){}
 public List<ProjectView> all(){return projects.findAllByOrderByCreatedAtDesc().stream().map(this::view).toList();}
 public ProjectView create(ProjectRequest r){
  if(r.name()==null||r.name().isBlank()||r.client()==null||r.client().isBlank()||r.dueDate()==null) throw new IllegalArgumentException("Project name, client and due date are required");
  Project p=new Project();p.setName(r.name().trim());p.setDescription(r.description());p.setClient(r.client().trim());p.setDueDate(r.dueDate());p.setOwner(current.get());
  return view(projects.save(p));
 }
 private ProjectView view(Project p){return new ProjectView(p.getId(),p.getName(),p.getDescription(),p.getClient(),p.getStatus(),p.getDueDate(),p.getOwner().getFullName());}
}
