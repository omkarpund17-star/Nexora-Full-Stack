package com.nexora.controller;

import com.nexora.repo.UserRepository;
import com.nexora.service.AuthService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/team")
public class TeamController {
 private final UserRepository users; private final AuthService auth;
 public TeamController(UserRepository u,AuthService a){users=u;auth=a;}
 @GetMapping public List<AuthService.UserView> all(){return users.findAll().stream().map(auth::view).toList();}
}
